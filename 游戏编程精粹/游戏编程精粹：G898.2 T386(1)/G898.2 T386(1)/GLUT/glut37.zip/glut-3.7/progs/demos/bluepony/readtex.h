/* readtex.h */

#ifndef READTEX_H
#define READTEX_H

#include <GL/gl.h>

extern GLboolean LoadRGBMipmaps(const char *imageFile, GLint intFormat);

#endif
