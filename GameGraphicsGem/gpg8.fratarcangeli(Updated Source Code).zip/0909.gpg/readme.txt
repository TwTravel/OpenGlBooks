Anatomical Human Face Model - Game Programming Gems 8
by Marco Fratarcangeli - 2010
  marco@fratarcangeli.net
  www.fratarcangeli.net

  
Here, you find two directories: 

.movies. 
Animations achieved using the anatomical simulator. 

.source. 
The source code of a demo which implements the main constraints used in the Position Based Dynamics method.
You can inflate and interact with deformable bodies with variuos shapes, like a pig, a dodecahedron and so on.

Each directory contains the correspondent readme.


Enjoy and feel free to drop me an email if you have any question,
  Marco
