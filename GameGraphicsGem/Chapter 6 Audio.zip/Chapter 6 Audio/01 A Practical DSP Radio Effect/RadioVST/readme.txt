This is the unoptimized version of the Radio effect described in Game Programming Gems 8.

This code is intentionally simple and does not depend on any outside libraries.

It is designed to be inserted into any audio effect plug-in code (such as VST, XAPO,  WWise, etc) that processes mono floating-point audio in blocks. It has been compiled and tested on Windows with Microsoft Visual Studio 2008,
but it should compile with minor changes on mac/linux as well.

 
