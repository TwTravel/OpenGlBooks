Make sure to set your working directory to here so the assets can be properly located by the code.  Do this in your Visual Studio Project settings.
