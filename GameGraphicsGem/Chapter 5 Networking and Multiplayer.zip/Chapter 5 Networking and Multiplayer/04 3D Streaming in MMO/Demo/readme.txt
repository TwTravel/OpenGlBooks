Point to an installed version of D3D SDK. This has been tested to link against the august 2009 version.

Need to set the working directory to be the debug or release directory depending on which one you are building so the shaders and other content are located.



