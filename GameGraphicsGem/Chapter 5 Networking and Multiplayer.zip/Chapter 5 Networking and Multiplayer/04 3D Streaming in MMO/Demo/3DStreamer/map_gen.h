#ifndef _MAPGEN
#define _MAPGEN

void GenerateRandomTerrain(Terrain* terrain);

#endif
